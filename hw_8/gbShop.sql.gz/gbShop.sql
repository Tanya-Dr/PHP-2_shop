-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Янв 31 2022 г., 19:09
-- Версия сервера: 10.4.17-MariaDB
-- Версия PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `gbShop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `idGood` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `idOrder` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`id`, `idGood`, `quantity`, `idUser`, `date`, `idOrder`) VALUES
(15, 4, 1, 2, '2021-12-10 14:32:05', 28),
(17, 11, 2, 2, '2021-12-10 14:32:10', 28),
(18, 15, 2, 8, '2021-12-10 16:26:42', 26),
(19, 10, 1, 8, '2021-12-10 16:26:52', 26),
(33, 1, 1, 1, '2021-12-19 22:04:24', 27),
(34, 3, 2, 1, '2021-12-19 22:04:25', 27),
(35, 15, 1, 10, '2021-12-20 00:06:37', 1),
(36, 12, 3, 10, '2021-12-20 00:06:40', 1),
(37, 14, 1, 10, '2021-12-20 14:44:37', 1),
(38, 4, 1, 10, '2021-12-20 18:54:56', 2),
(39, 8, 1, 10, '2021-12-20 18:55:00', 2),
(40, 13, 1, 10, '2021-12-20 18:55:02', 2),
(41, 9, 1, 10, '2021-12-20 19:03:54', 25),
(42, 13, 1, 10, '2021-12-20 19:57:32', 0),
(113, 1, 1, 1, '2022-01-24 12:46:23', 34),
(115, 8, 1, 1, '2022-01-24 19:03:44', 34),
(117, 7, 1, 1, '2022-01-24 19:47:25', 35),
(118, 11, 1, 1, '2022-01-24 19:48:08', 36),
(119, 9, 1, 1, '2022-01-24 19:49:12', 37),
(120, 1, 1, 2, '2022-01-24 19:54:16', 38),
(121, 12, 1, 2, '2022-01-24 20:57:11', 39),
(122, 3, 1, 2, '2022-01-25 19:39:48', 40),
(127, 1, 1, 8, '2022-01-25 22:43:00', 41),
(128, 8, 2, 8, '2022-01-25 22:43:03', 41),
(131, 2, 2, 1, '2022-01-31 20:48:37', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `title` varchar(20) NOT NULL,
  `price` double NOT NULL,
  `shortInfo` text NOT NULL,
  `fullInfo` text NOT NULL,
  `img` varchar(20) NOT NULL,
  `countView` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `title`, `price`, `shortInfo`, `fullInfo`, `img`, `countView`) VALUES
(1, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 51),
(2, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis!', 'card_2.png', 52),
(3, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 40),
(4, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 57),
(7, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 8),
(8, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 22),
(9, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 7),
(10, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 12),
(11, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 7),
(12, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 6),
(13, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(14, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 7),
(15, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 9),
(75, 'title', 10, 'short Info', 'full Info!', '_.jpeg', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `statusOrder` int(11) NOT NULL,
  `dateOrder` datetime NOT NULL,
  `totalSum` double NOT NULL,
  `deliveryPrice` double DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phoneNumber` varchar(20) DEFAULT NULL,
  `idUser` int(11) DEFAULT NULL,
  `lastUpdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `statusOrder`, `dateOrder`, `totalSum`, `deliveryPrice`, `address`, `phoneNumber`, `idUser`, `lastUpdate`) VALUES
(1, 4, '2021-12-20 16:20:00', 10197.09, 200, 'Moscow', '+7(900)123-45-45', 10, '2021-12-20 16:20:00'),
(2, 4, '2021-12-20 18:55:16', 8699.99, 300, 'Moscow', '+7(900)123-45-45', 10, '2022-01-29 23:49:04'),
(25, 3, '2021-12-20 19:11:39', 10000.99, 200, 'Moscow', '+7(900)123-45-45', 10, '2021-12-20 19:11:39'),
(26, 2, '2021-12-20 20:02:26', 9499.18, 200, 'Kazan', '+7(999)123-45-65', 8, '2021-12-20 20:02:26'),
(27, 2, '2021-12-20 21:27:26', 16002.97, 300, 'Moscow', '+7(999)000-00-00', 1, '2021-12-20 21:27:26'),
(28, 2, '2021-12-20 21:30:11', 6199.99, 200, 'Saint Petersburg', '+7(999)111-22-33', 2, '2022-01-29 01:06:25'),
(34, 3, '2022-01-24 19:45:17', 12000.99, 300, 'Moscow', '+7(900)123-45-45', 1, '2022-01-28 21:44:43'),
(35, 3, '2022-01-24 19:47:35', 3999, 200, 'Kazan', '+7(999)000-00-00', 1, '2022-01-28 21:37:02'),
(36, 3, '2022-01-24 19:48:19', 100, 300, 'Moscow', '+7(999)000-00-00', 1, '2022-01-28 21:37:39'),
(37, 3, '2022-01-24 19:49:22', 10000.99, 300, 'Saint Petersburg', '+7(999)111-22-33', 1, '2022-01-31 20:54:26'),
(38, 3, '2022-01-24 19:54:25', 10000.99, 300, 'Saint Petersburg', '+7(999)123-45-65', 2, '2022-01-28 21:40:50'),
(39, 3, '2022-01-24 20:57:20', 899, 300, 'Kazan', '+7(900)123-45-45', 2, '2022-01-24 20:57:20'),
(40, 3, '2022-01-25 20:11:32', 3000.99, 300, 'Kazan', '+7(900)123-45-45', 2, '2022-01-28 21:44:36'),
(41, 2, '2022-01-25 22:43:25', 14000.99, 300, 'Kazan', '+7(999)111-22-33', 8, '2022-01-28 21:47:32');

-- --------------------------------------------------------

--
-- Структура таблицы `orderStatus`
--

CREATE TABLE `orderStatus` (
  `id` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `orderStatus`
--

INSERT INTO `orderStatus` (`id`, `status`) VALUES
(1, 'pending payment'),
(2, 'processing'),
(3, 'shipped'),
(4, 'delivered'),
(5, 'failed');

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `text` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `text`, `date`) VALUES
(1, 'anonymous1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur, alias.', '2021-12-06 10:00:00'),
(2, 'Tanya', 'good', '2021-12-07 06:06:20'),
(3, 'vanDull', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda sunt ducimus cum minus placeat, quos!', '2021-12-07 06:08:19'),
(4, 'spider', 'Cooooooooool!!!!', '2021-12-07 06:14:44'),
(5, 'Smn', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', '2021-12-07 13:43:11'),
(6, 'test', 'test', '2021-12-07 15:02:45'),
(7, 'test2', 'test2', '2021-12-07 15:07:07'),
(8, 'Tanya', 'Hi!', '2021-12-09 19:00:05'),
(9, 'smn', 'Check', '2021-12-13 09:18:01'),
(10, 'Kostya', 'Hello!!!', '2021-12-13 09:41:51'),
(11, 'spider', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda sunt ducimus cum minus placeat, quos!', '2021-12-13 09:44:24'),
(12, 'spider', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda sunt ducimus cum minus placeat, quos!', '2021-12-13 09:44:54'),
(13, 'anonymous1', 'Lorem', '2021-12-13 09:47:25'),
(14, 'admin', 'Just check', '2021-12-19 11:08:48'),
(18, 'Tanya', 'check', '2021-12-19 11:11:55'),
(24, 'Tanya', 'test', '2021-12-19 21:33:15'),
(26, 'Tanya', 'Lorem ipsum dolor sit amet.', '2021-12-19 21:37:28'),
(27, 'admin', 'check', '2022-01-24 10:41:16');

-- --------------------------------------------------------

--
-- Структура таблицы `testGoods`
--

CREATE TABLE `testGoods` (
  `id` int(11) NOT NULL,
  `title` varchar(20) NOT NULL,
  `price` double NOT NULL,
  `shortInfo` text NOT NULL,
  `fullInfo` text NOT NULL,
  `img` varchar(20) NOT NULL,
  `countView` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `testGoods`
--

INSERT INTO `testGoods` (`id`, `title`, `price`, `shortInfo`, `fullInfo`, `img`, `countView`) VALUES
(1, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(2, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(3, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(4, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(7, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(8, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(9, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(10, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(11, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(12, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(13, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(14, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(15, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(16, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(17, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(18, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(19, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(20, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(21, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(22, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(23, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(24, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(25, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(26, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(27, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(28, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(29, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(30, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(31, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(32, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(33, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(34, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(35, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(36, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(37, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(38, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(39, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(40, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(41, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(42, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(43, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(44, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(45, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(46, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(47, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(48, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(49, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(50, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(51, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(52, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(53, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(54, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(55, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(56, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(57, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(58, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(59, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(60, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(61, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(62, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(63, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(64, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(65, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(66, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(67, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(68, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(69, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(70, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(71, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(72, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(73, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(74, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(75, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(76, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(77, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(78, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(79, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(80, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(81, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(82, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(83, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(84, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(85, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(86, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(87, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(88, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(89, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(90, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(91, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(92, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(93, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(94, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(95, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(96, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(97, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(98, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(99, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(100, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(101, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(102, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(103, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(104, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(105, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(106, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(107, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(108, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(109, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(110, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(111, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(112, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(113, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(114, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(115, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(116, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(117, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(118, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(119, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(120, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(121, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(122, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(123, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(124, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5),
(125, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(126, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(127, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(128, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(129, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(130, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(131, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(132, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5),
(133, 'jacket', 10000.99, 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, totam!', 'Jacket - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Id officia sit hic, accusantium rerum ducimus. Facilis voluptatum laudantium placeat quibusdam porro laboriosam dignissimos assumenda commodi accusamus in praesentium hic nobis quae nihil quas dolore, ut officia veniam. Enim, autem fuga voluptas obcaecati animi culpa, nostrum dolores sunt, saepe repellat ducimus.', 'card_1.png', 34),
(134, 'costume', 7500.11, 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, voluptate.', 'Costume - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam inventore quis earum nostrum adipisci excepturi neque distinctio reiciendis. Nam, reiciendis.', 'card_2.png', 49),
(135, 'shorts', 3000.99, 'Shorts - Lorem ipsum dolor sit amet, consectetur.', 'Shorts - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, eveniet dignissimos consequatur ut accusamus quidem facere numquam nesciunt vel doloremque!', 'card_3.png', 32),
(136, 'trousers', 5999.99, 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente, quibusdam.', 'Trousers - Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt provident, iusto autem veritatis cumque rem neque dolor explicabo consequatur. Eaque id minima, sapiente provident modi vel libero perferendis, enim expedita.', 'card_4.png', 47),
(137, 'blazer', 3999, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, inventore!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum deleniti fugit deserunt aperiam, quaerat corporis illum quia ea aliquid neque eaque atque repellendus laborum veritatis.', 'card_5.png', 5);
INSERT INTO `testGoods` (`id`, `title`, `price`, `shortInfo`, `fullInfo`, `img`, `countView`) VALUES
(138, 'leggings', 2000, 'Lorem ipsum dolor sit amet.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'product.png', 15),
(139, 'bomber', 10000.99, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste est nulla magnam, laudantium, repellendus sint soluta corporis quidem et labore nostrum rem nesciunt, blanditiis quae odit. Soluta non minus earum.', 'man_card_2.png', 5),
(140, 'T-shirt', 499, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, numquam.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_5.png', 6),
(141, 'cap', 100, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam molestiae nostrum, fugiat ipsum. Perferendis ullam praesentium ducimus itaque nemo libero, delectus sapiente magnam? Doloribus dolore sed, illo, laboriosam consequatur assumenda dolores! Dolor eligendi quaerat sint.', 'man_card_6.png', 5),
(142, 'belt', 899, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt obcaecati illum, placeat praesentium distinctio quod, sed necessitatibus dicta, voluptatum fugit beatae aperiam quasi possimus veniam.', 'man_card_7.png', 5),
(143, 'hat', 700, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident ipsa saepe vitae dolor? Beatae maiores sed explicabo voluptas, vitae et est voluptate inventore. Illo reprehenderit blanditiis assumenda pariatur consectetur molestias, temporibus, non at adipisci fugit et! Nam corporis sunt molestias? Obcaecati non eveniet expedita repellendus totam, accusantium nemo minima provident.', 'man_card_8.png', 6),
(144, 'shirt', 3000, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem tenetur officia neque! Perferendis nesciunt beatae ut inventore neque, esse in? Itaque architecto, cupiditate alias quasi repellat mollitia hic minus odit in laboriosam voluptatum. Voluptatum animi nemo, veritatis cumque, omnis earum.', 'man_card_9.png', 5),
(145, 'blouse', 4500.09, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.!!!!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium exercitationem repudiandae expedita nisi veritatis ea voluptas quod fugit, eum fuga, asperiores commodi molestiae accusamus blanditiis delectus earum, possimus minima aut ipsa eius, cupiditate! Similique, veniam.', 'card_6.png', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `nickname`, `email`, `pass`, `admin`) VALUES
(1, 'admin', 'admin@admin.ru', 'sldfjsklfdj23lfd0,.sd827ccb0eea8a706c4c34a16891f84e7bsldfjsklfdj23lfd0,.sd', 2),
(2, 'user1', 'user1@email.ru', 'sldfjsklfdj23lfd0,.sdee11cbb19052e40b07aac0ca060c23eesldfjsklfdj23lfd0,.sd', 0),
(8, 'Tanya', 'tanya@email.ru', 'sldfjsklfdj23lfd0,.sddd1c91ab96bf4aacc235c3bc7d9e540asldfjsklfdj23lfd0,.sd', 1),
(10, 'Spider', 'spider1@email.ru', 'sldfjsklfdj23lfd0,.sd6086ea656aeb8c6f021ecc2d90ac1133sldfjsklfdj23lfd0,.sd', 1),
(11, 'Smn', 'smn@email.ru', 'c8c9446f170ec7de8c8ca85505ba85e6', 0),
(13, 'Smn_New', 'new@email.ru', 'sldfjsklfdj23lfd0,.sd018c70cdb26759077ed26df28c117033sldfjsklfdj23lfd0,.sd', 0),
(14, 'GB', 'gb@email.ru', 'sldfjsklfdj23lfd0,.sd33182e8aa1062377b8eaca203570a06dsldfjsklfdj23lfd0,.sd', 0),
(15, 'gbStudent', 'gbStudent@email.ru', 'sldfjsklfdj23lfd0,.sd375fecc3c63f65de945f43c187aaf840sldfjsklfdj23lfd0,.sd', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orderStatus`
--
ALTER TABLE `orderStatus`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `testGoods`
--
ALTER TABLE `testGoods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT для таблицы `orderStatus`
--
ALTER TABLE `orderStatus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT для таблицы `testGoods`
--
ALTER TABLE `testGoods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
